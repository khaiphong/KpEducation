# KpEducation

Sustainable Education to promote "<b>Core Values of Honesty &amp; Care</b>"
