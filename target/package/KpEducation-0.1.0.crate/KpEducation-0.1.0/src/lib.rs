//! # KpEducation
//!
//! A collection of utilities to enable KpEducation happened and efficient.

